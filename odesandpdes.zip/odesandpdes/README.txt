----------------------------------------------------------------
odesandpdes --- A package for the streamlining of the use of
odes and pdes in mathematical texts typset by LaTeX

E-mail: anakin@ruc.dk
Released under the LaTeX Project Public License v1.3c or later
See http://www.latex-project.org/lppl.txt
----------------------------------------------------------------

This package is the solution no one asked for, to a problem
nobody had. Have you ever thought to yourself "wow, I sure do
dislike having to remember multiple macros for my odes and pdes"
and the author of this package has to agree, wholeheartedly.
In the modern world of "tik-toking" and "family guy surfing",
our brains have rotted beyond salvage for even basic levels of
cognitive recall. This package aims to fix this, through two
macros that have been set to each have an identical form and
function. with an emphasis on intuitive use. Through setting
options, the multiple common notational style are easily
swapped between, all by a single option.
You're Welcome.

----------------------------------------------------------------
